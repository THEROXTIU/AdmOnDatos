<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gráfica Proyecto Final.</title>
    <link rel="stylesheet" href="./css/chartist.min.css">
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/estilos.css">
    <script src="./js/chartist.min.js"></script>
    <style>
        body {background-color: #DFDBE5;
background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='34' height='44' viewBox='0 0 34 44'%3E%3Cg fill='%23c0a7d9' fill-opacity='0.4'%3E%3Cpath fill-rule='evenodd' d='M1 6.2C.72 5.55.38 4.94 0 4.36v13.28c.38-.58.72-1.2 1-1.84A12.04 12.04 0 0 0 7.2 22 12.04 12.04 0 0 0 1 28.2c-.28-.65-.62-1.26-1-1.84v13.28c.38-.58.72-1.2 1-1.84A12.04 12.04 0 0 0 7.2 44h21.6a12.05 12.05 0 0 0 5.2-4.36V26.36A12.05 12.05 0 0 0 28.8 22a12.05 12.05 0 0 0 5.2-4.36V4.36A12.05 12.05 0 0 0 28.8 0H7.2A12.04 12.04 0 0 0 1 6.2zM17.36 23H12a10 10 0 1 0 0 20h5.36a11.99 11.99 0 0 1 0-20zm1.28-2H24a10 10 0 1 0 0-20h-5.36a11.99 11.99 0 0 1 0 20zM12 1a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 14a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-3.46-2a2 2 0 1 0-3.47 2 2 2 0 0 0 3.47-2zm0-4a2 2 0 1 0-3.47-2 2 2 0 0 0 3.47 2zM12 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm3.46 2a2 2 0 1 0 3.47-2 2 2 0 0 0-3.47 2zm0 4a2 2 0 1 0 3.47 2 2 2 0 0 0-3.47-2zM24 43a10 10 0 1 0 0-20 10 10 0 0 0 0 20zm0-14a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm3.46 2a2 2 0 1 0 3.47-2 2 2 0 0 0-3.47 2zm0 4a2 2 0 1 0 3.47 2 2 2 0 0 0-3.47-2zM24 37a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-3.46-2a2 2 0 1 0-3.47 2 2 2 0 0 0 3.47-2zm0-4a2 2 0 1 0-3.47-2 2 2 0 0 0 3.47 2z'/%3E%3C/g%3E%3C/svg%3E");}
        </style>
    <style>
    .boton {
        padding: 5px;
        background-color: rgb(82, 20, 133);
        color: white;
    }
        </style>
        <a href="tableTvScranton.php" class="boton">TABLE</a>
</head>

<body>
    <div class="container">
        <div class="centro">
            <div class="dev">
                <h1>Televisores capturados en Diferentes Viviendas en Scranton.</h1>
                <span class="subt">25,000 capturas en diferentes viviendas de Scranton.</span>
                <span class="dev">Elaborado por Iago Brian Lorenzana Reyes 182310133.</span>
    </div>
            
    <div class="ct-chart ct-minor-seventh"></div>
<?php           //Para empezar la lógica que tomé fue que en la serie de los 25,000 registros hay un patrón el cual sólo son números de 0 al 5 así que decidí contar cuántos números hay del mismo.
                //abrimos el archivo con la función explode, junto con la dirección de nuestro archivo de texto, y con la función str y substr_count para hacer la el contenido de cadena y hacer un conteo de cuantos 0 hay en el archivo de texto                
                $array = explode("\n", file_get_contents('./txt/tvsByEachLivingPlaces.txt'));
                $str = ", " . implode(", ",$array) . ",";
                $count0 = substr_count($str, '0');

                //Aquí hacemos lo mismo pero con el número 1
                $str = ", " . implode(", ",$array) . ",";
                $count1 = substr_count($str, '1');
                
                //Aquí hacemos lo mismo pero con el número 2
                $str = ", " . implode(", ",$array) . ",";
                $count2 = substr_count($str, '2');
                //Aquí hacemos lo mismo pero con el número 3
                $str = ", " . implode(", ",$array) . ",";
                $count3 = substr_count($str, '3');
                //Aquí hacemos lo mismo pero con el número 4
                
                $str = ", " . implode(", ",$array) . ",";
                $count4 = substr_count($str, '4');
                //Aquí hacemos lo mismo pero con el número 5

                $str = ", " . implode(", ",$array) . ",";
                $count5 = substr_count($str, '5');
                //Asignamos a un array cada uno de los valores que tiene cada variable, ya que cada variable tiene la cantidad de cada uno de los números junto con la cantidad exacta ya anteriormente verificada en el archivo /prueba/prueba.php
                $datostv=array("Viviendas con 0 TVs 981"=> $count0, "Viviendas con 1 TVs 1019"=> $count1, "Viviendas con 2 TVs 10976"=> $count2, "Viviendas con 3 TVs 11024"=> $count3, "Viviendas con 4 TVs 502"=> $count4, "Viviendas con 5 TVs 498"=> $count5);
                //Aquí represento el array de $datostv en JSON y lo guardo en la ruta /json/tv.json para poder usarlo después
                
                $json_string = json_encode($datostv);
                $file = './json/tv.json';
                file_put_contents($file, $json_string);
                //Abro el archivo JSON recientemente creado
                $archivo = './json/tv.json';
        
                $handle = fopen($archivo, 'r')
                or die("Error: No se puede abrir el archivo json");
                
                $size = filesize($archivo);
                
                $contenido = fread($handle, $size);
                
                fclose($handle);
                //Decodificamos nuestro archivo y sí contiene algo proseguimos
                $lista_tv = json_decode($contenido, true);
                //Asignamos los valores al igual que las etiquetas
                $lista_labels = array();
                $lista_valores = array();
                //Recorremos el archivo
                foreach ($lista_tv as $vivienda => $tv) {
                    $lista_labels[] = $vivienda;
                    $lista_valores[] = $tv;
                }
                
                //Empieza el script de JC
                ?>
                <script>

                var datos = {

                    labels: [
                        '<?php echo $lista_labels[0]; ?>',
                        '<?php echo $lista_labels[1]; ?>',
                        '<?php echo $lista_labels[2]; ?>',
                        '<?php echo $lista_labels[3]; ?>',
                        '<?php echo $lista_labels[4]; ?>',
                        '<?php echo $lista_labels[5]; ?>'
                    ],
                    series: [{
                        name: 'serie-1',
                        data: [
                            <?php echo $lista_valores[0]; ?>,
                            <?php echo $lista_valores[1]; ?>,
                            <?php echo $lista_valores[2]; ?>,
                            <?php echo $lista_valores[3]; ?>,
                            <?php echo $lista_valores[4]; ?>,
                            <?php echo $lista_valores[5]; ?>,      
                        
                                
                        ]
                    }]
                };
                //configuro los patrones de nuestra gráfica de barras
                var opciones = {
                    seriesBarDistance: 15
                        };
                        var opcionesResponsive = [
                            ['screen and (min-width: 641px) and (max-width: 1024px)', {
                                seriesBarDistance: 200,
                                axisX: {
                                    labelInterpolationFnc: function (value) {
                                        return value;
                                    }
                                }
                            }],
                            ['screen and (max-width: 640px)', {
                                seriesBarDistance: 5,
                                axisX: {
                                    labelInterpolationFnc: function (value) {
                                        return value[0];    
                                    }
                                }
                            }]       
                        ];
                        new Chartist.Bar('.ct-chart', datos, opciones, opcionesResponsive);
                </script>
        </div>    
    </div>
</body>
</html>