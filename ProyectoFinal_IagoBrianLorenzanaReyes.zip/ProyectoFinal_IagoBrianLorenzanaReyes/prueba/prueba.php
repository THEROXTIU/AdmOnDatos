<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php
    
        $array = explode("\n", file_get_contents('tvsByEachLivingPlaces.txt'));
        $str = ", " . implode(", ",$array) . ",";
        $count0 = substr_count($str, '0');

        echo $count0;
        echo "<br>";
        $str = ", " . implode(", ",$array) . ",";
        $count1 = substr_count($str, '1');
        echo $count1;
        echo "<br>";
        $str = ", " . implode(", ",$array) . ",";
        $count2 = substr_count($str, '2');
        echo $count2;
        echo "<br>";
        $str = ", " . implode(", ",$array) . ",";
        $count3 = substr_count($str, '3');
        echo $count3;
        echo "<br>";
        $str = ", " . implode(", ",$array) . ",";
        $count4 = substr_count($str, '4');
        echo $count4;
        echo "<br>";
        $str = ", " . implode(", ",$array) . ",";
        $count5 = substr_count($str, '5');
        echo $count5;
        echo "<br>";
        $datostv=array("Viviendas con 0 TVs"=> $count0, "Viviendas con 1 TVs"=> $count1, "Viviendas con 2 TVs"=> $count2, "Viviendas con 3 TVs"=> $count3, "Viviendas con 4 TVs"=> $count4, "Viviendas con 5 TVs"=> $count5);
        var_dump($datostv);

        $json_string = json_encode($datostv);
        $file = './json/tv.json';
        file_put_contents($file, $json_string);
        
        
       
    ?>
    
</body>
</html>